package ExamPrep.GoldDiggerApp.src.main.java.goldDigger.models.discoverer;

public class Archeologist extends BaseDiscoverer{

    private static final double ARCHEOLOGIST_ENERGY = 60;

    public Archeologist(String name) {
        super(name, ARCHEOLOGIST_ENERGY);
    }
}
