package ExamPrep.GoldDiggerApp.src.main.java.goldDigger.core;

public interface Engine extends Runnable{

}
