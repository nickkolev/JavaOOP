package ExamPrep.GoldDiggerApp.src.main.java.goldDigger;

import ExamPrep.GoldDiggerApp.src.main.java.goldDigger.core.Controller;
import ExamPrep.GoldDiggerApp.src.main.java.goldDigger.core.ControllerImpl;
import ExamPrep.GoldDiggerApp.src.main.java.goldDigger.core.Engine;
import ExamPrep.GoldDiggerApp.src.main.java.goldDigger.core.EngineImpl;

public class Main {

    public static void main(String[] args) {
        Controller controller = new ControllerImpl();
        Engine engine = new EngineImpl(controller);
        engine.run();
    }
}
