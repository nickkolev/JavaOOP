package ExamPrep.GoldDiggerApp.src.main.java.goldDigger.models.operation;

import ExamPrep.GoldDiggerApp.src.main.java.goldDigger.models.discoverer.Discoverer;
import ExamPrep.GoldDiggerApp.src.main.java.goldDigger.models.spot.Spot;

import java.util.Collection;

public interface Operation {
    void startOperation(Spot spot, Collection<Discoverer> discoverers);

}
